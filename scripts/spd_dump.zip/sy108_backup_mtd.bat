@echo off
echo ��Ϊ5GͨѶ�� sy108 / UDX710 MTD��������
if not exist backup md backup
spd_dump --wait 600 skip_confirm 1 exec_addr 0x3f28 fdl fdl1 0x28007000 fdl fdl2 0x9efffe00 exec path backup r splloader splloader.bin r uboot uboot.bin r sml sml.bin r trustos trustos.bin r ubootbak ubootbak.bin r smlbak smlbak.bin r trustosbak trustosbak.bin r ubipac ubipac.bin reset
pause
