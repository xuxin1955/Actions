@echo off
echo ��Ϊ5GͨѶ�� sy108 / UDX710 MTD���� + UBI��������
if not exist backup md backup
spd_dump --wait 600 skip_confirm 1 exec_addr 0x3f28 fdl fdl1 0x28007000 fdl fdl2 0x9efffe00 exec path backup r splloader r uboot r sml r trustos r ubootbak r smlbak r trustosbak r miscdata r misc r nr_fixnv1 r nr_fixnv2 r prodnv r nr_runtimenv1 r nr_runtimenv2 r persist r boot r recovery r nr_pmsys r nr_agdsp r nr_modem r nr_v3phy r nr_nrphy r nr_nrdsp1 r nr_nrdsp2 r nr_deltanv r system r m_raw r m_data r m_webui r userdata reset
pause
