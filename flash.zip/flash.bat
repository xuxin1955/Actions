@echo off
chcp 65001 >nul
echo OpenStick Bootloader
echo please make sure your device in fastboot mode
pause
fastboot erase boot
fastboot flash boot lk2nd.img
fastboot reboot
echo when detected a fastboot device
pause
echo [1/4] fsc ...
fastboot oem read-partition fsc      && fastboot get_staged fsc.bin      || goto :bbfail
echo [2/4] fsg ...
fastboot oem read-partition fsg      && fastboot get_staged fsg.bin      || goto :bbfail
echo [3/4] modemst1 ...
fastboot oem read-partition modemst1 && fastboot get_staged modemst1.bin || goto :bbfail
echo [4/4] modemst2 ...
fastboot oem read-partition modemst2 && fastboot get_staged modemst2.bin || goto :bbfail
for %%f in (fsc.bin fsg.bin modemst1.bin modemst2.bin) do (
    for %%s in (%%f) do if %%~zs equ 0 goto :bbfail
)
echo [+] 回读基带成功
fastboot erase boot
fastboot reboot bootloader
echo when detected a fastboot device
pause
fastboot flash partition gpt_both0-fixed.bin
fastboot flash hyp hyp.mbn
fastboot flash rpm rpm.mbn
fastboot flash sbl1 sbl1.mbn
fastboot flash tz tz.mbn
fastboot flash fsc fsc.bin
fastboot flash fsg fsg.bin
fastboot flash modemst1 modemst1.bin
fastboot flash modemst2 modemst2.bin
fastboot flash aboot aboot.bin
fastboot flash cdt sbc_1.0_8016.bin
fastboot erase boot
fastboot erase rootfs
fastboot erase rootfs_data
fastboot reboot bootloader
fastboot flash boot boot.img
fastboot flash rootfs rootfs.img
fastboot reboot
del /f /q fsc.bin fsg.bin modemst1.bin modemst2.bin
echo flashing debian!
echo when detected a fastboot device
pause
exit /b 0
:bbfail
echo.
echo ==========================================
echo  回读基带失败！不要继续刷机！
echo  重新运行本脚本
echo ==========================================
pause
exit /b 1
